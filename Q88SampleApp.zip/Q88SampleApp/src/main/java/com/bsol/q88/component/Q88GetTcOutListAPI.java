package com.bsol.q88.component;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bsol.q88.model.Q88_TcOutList;
import com.bsol.q88.service.Q88TcOutListService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

@Component
@EnableScheduling
public class Q88GetTcOutListAPI {

	@Autowired
	private CheckToken checkToken;

	@Autowired
	private AccessToken token;

	@Autowired
	private RefreshToken refreshtoken;

	@Autowired
	private Q88TcOutListService tcoutService;

	@Scheduled(cron = "0 */1 * ? * *")
	void checkTokenExpires() throws Exception {

		String expireResult = checkToken.checkTokenExpires();

		if (expireResult.equals("before")) {
			getTcOutList();

		} else if (expireResult.equals("after")) {
			refreshtoken.getAccessTokenByRefreshToken();
			getTcOutList();
			

		} else if (expireResult.equals("expired")) {
			token.getAccessToken();
			getTcOutList();

		}
	}

	void getTcOutList() throws Exception {

		String modifiedDate = tcoutService.getLastRuntime("GetTCOutList");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/ HH:mm:ss");
		Date date = new Date();
		String update = dateFormat.format(date).toString();
		JSONArray json1;
		List<Q88_TcOutList> Q88source = new ArrayList<Q88_TcOutList>();
		PropertiesConfiguration properties = new PropertiesConfiguration("src/main/resources/token.properties");

		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(30, TimeUnit.SECONDS);
		client.setReadTimeout(30, TimeUnit.SECONDS);
		client.setWriteTimeout(30, TimeUnit.SECONDS);
		String token = properties.getProperty("q88.token.access_token").toString();
		String url = "https://webapi.q88.com/TCOut/GetTCOutList?modifiedDate=" + modifiedDate;
		Request request = new Request.Builder().url(url).addHeader("Authorization", "Bearer " + token).build();
		try {

			Response response = client.newCall(request).execute();
			Q88_TcOutList tcoutobj = new Q88_TcOutList();

			if (!response.isSuccessful()) {
				throw new IOException("Unexpected code " + response);
			}
			json1 = new JSONArray(response.body().string().toString());
			Gson gson = new GsonBuilder().serializeNulls().create();
			for (int i = 0; i < json1.length(); i++) {
				Q88_TcOutList tcout = gson.fromJson(json1.getJSONObject(i).toString(), Q88_TcOutList.class);
				//System.out.println(tcout);
				tcoutService.saveTcOutList(tcout);
				// tcoutobj = tcoutService.getVoyageobject("C33E200DE88DB38F417C143075CF38E1",
				// "CFDED89B095BD54C3C9FA770EF3A2C4E");
				// System.out.println(tcoutobj);
			}
			System.out.println("inserted ");
		}

		catch (SocketTimeoutException expected) {
			getTcOutList();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
