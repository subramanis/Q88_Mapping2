/*
 * package com.bsol.q88.dao;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.bsol.q88.model.Q88_FixtureBillOfLading;
 * 
 * public interface Q88_FixtureBillOfLadingDao extends
 * JpaRepository<Q88_FixtureBillOfLading, Integer>{
 * 
 * }
 */