/*
 * package com.bsol.q88.dao;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.bsol.q88.model.Q88_FixtureExpense;
 * 
 * public interface Q88_FixtureExpenseDao extends
 * JpaRepository<Q88_FixtureExpense, Integer>{
 * 
 * }
 */