package com.bsol.q88.dto;

public class Q88_TcOutListDTO {
	
	
	private Integer tcout_SeqId;
	private String tcOutIdEncrypted ;
	private String vesselIdEncrypted;
	private String vessel;
	private String charterer;
	private String cpDate;
	private String tcNumber;
	private String duration;
	private String startDate;
	private String modifiedDate;
	private String modifiedBy;
	
	
	public Integer getTcout_SeqId() {
		return tcout_SeqId;
	}
	public void setTcout_SeqId(Integer tcout_SeqId) {
		this.tcout_SeqId = tcout_SeqId;
	}
	public String getTcOutIdEncrypted() {
		return tcOutIdEncrypted;
	}
	public void setTcOutIdEncrypted(String tcOutIdEncrypted) {
		this.tcOutIdEncrypted = tcOutIdEncrypted;
	}
	public String getVesselIdEncrypted() {
		return vesselIdEncrypted;
	}
	public void setVesselIdEncrypted(String vesselIdEncrypted) {
		this.vesselIdEncrypted = vesselIdEncrypted;
	}
	public String getVessel() {
		return vessel;
	}
	public void setVessel(String vessel) {
		this.vessel = vessel;
	}
	public String getCharterer() {
		return charterer;
	}
	public void setCharterer(String charterer) {
		this.charterer = charterer;
	}
	public String getCpDate() {
		return cpDate;
	}
	public void setCpDate(String cpDate) {
		this.cpDate = cpDate;
	}
	public String getTcNumber() {
		return tcNumber;
	}
	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
}
