/*
 * package com.bsol.q88.dao;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.bsol.q88.model.Q88_FixtureTagData;
 * 
 * public interface Q88_FixtureTagDataDao extends
 * JpaRepository<Q88_FixtureTagData, Integer> {
 * 
 * }
 */