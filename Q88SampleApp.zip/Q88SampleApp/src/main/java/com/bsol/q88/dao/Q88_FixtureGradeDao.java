/*
 * package com.bsol.q88.dao;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.bsol.q88.model.Q88_FixtureGrade;
 * 
 * public interface Q88_FixtureGradeDao extends JpaRepository<Q88_FixtureGrade,
 * Integer>{
 * 
 * }
 */